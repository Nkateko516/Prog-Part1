/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;



/**
 *
 * @author hifi
 */
public class ChatAppGUI {
     public static void main(String[] args) {
        login login = new login();

         // === Custom colours for all dialogs ===
        Color yellowBg = Color.YELLOW;
        Color blackText = Color.BLACK;
        Color darkGreen = Color.decode("#006400"); // dark green border

        UIManager.put("OptionPane.background", yellowBg);
        UIManager.put("Panel.background", yellowBg);
        UIManager.put("OptionPane.messageForeground", blackText);
        UIManager.put("OptionPane.border", new LineBorder(darkGreen, 3));

        // === Registration loop ===
        while (true) {
            JOptionPane.showMessageDialog(
                    null,
                    "*** Account Registration ***\nPlease provide the requested details to create your profile.",
                    "Registration",
                    JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                    null,
                    "Choose a username (must include '_' and have no more than 5 characters):",
                    "Username",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (username == null) return; // user cancelled

            String password = JOptionPane.showInputDialog(
                    null,
                    "Create a password (at least 8 characters, must contain a capital letter, a number, and a special character):",
                    "Password",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(
                    null,
                    "Enter your cellphone number with the international code (e.g. ‪+27838968976‬):",
                    "Cellphone",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(
                    null,
                    regMessage,
                    "Registration Result",
                    JOptionPane.INFORMATION_MESSAGE
            );

            if (regMessage.equals("Registration successful.")) {
                break; // proceed to login
            }
            // otherwise loop again until valid
        }

        // === Login loop ===
        while (true) {
            JOptionPane.showMessageDialog(
                    null,
                    "*** User Login ***\nPlease enter your details to access your account.",
                    "Login",
                    JOptionPane.INFORMATION_MESSAGE
            );

            String username = JOptionPane.showInputDialog(
                    null,
                    "Username:",
                    "Login",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (username == null) return;

            String password = JOptionPane.showInputDialog(
                    null,
                    "Password:",
                    "Login",
                    JOptionPane.QUESTION_MESSAGE
            );
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());

            JOptionPane.showMessageDialog(
                    null,
                    msg,
                    ok ? "Login Successful" : "Login Failed",
                    ok ? JOptionPane.INFORMATION_MESSAGE : JOptionPane.ERROR_MESSAGE
            );

            if (ok) {
                break; // finish after successful login
            }
            // otherwise loop until correct
        }
    }
}