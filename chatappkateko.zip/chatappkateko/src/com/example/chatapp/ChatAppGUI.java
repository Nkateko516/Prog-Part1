/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example.chatapp;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;






/**
 *
 * @author hifi
 */
public class ChatAppGUI {
     public static void main(String[] args) {
        // === UI THEME ===
        UIManager.put("OptionPane.background", Color.YELLOW);  // yellow
        UIManager.put("Panel.background", Color.YELLOW);
        UIManager.put("OptionPane.messageForeground", Color.BLACK);    // black text
        UIManager.put("OptionPane.border", new LineBorder(Color.RED, 4)); // red border
        UIManager.put("Button.background", Color.WHITE);
        UIManager.put("Button.foreground", Color.BLACK);

        login login = new login();

        // === WELCOME / LOGO ===
        JLabel welcomeLabel = new JLabel(
                "<html><div style='text-align:center;'>"
                        + "<span style='font-size:28px;font-weight:bold;'>NKQuickChat</span><br>"
                        + "<span style='font-size:14px;'>Connecting you to the world, one message at a time 📱</span>"
                        + "</div></html>");
        welcomeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        JOptionPane.showMessageDialog(null, welcomeLabel, "Welcome", JOptionPane.PLAIN_MESSAGE);

        // === REGISTRATION ===
        while (true) {
            JOptionPane.showMessageDialog(null, "📝 Let's get you started!\nPlease provide your details.");

            String username = JOptionPane.showInputDialog(null, "Pick a username (must include '_' and be ≤ 5 characters):");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "Create a strong password (8+ chars, capital, number, special):");
            if (password == null) return;

            String cellphone = JOptionPane.showInputDialog(null, "Enter cellphone with international code (e.g. ‪+27838968976‬):");
            if (cellphone == null) return;

            String regMessage = login.registerUser(username.trim(), password, cellphone.trim());
            JOptionPane.showMessageDialog(null, regMessage);

            if (regMessage.equals("Registration successful.")) break;
        }

        // === LOGIN ===
        boolean loggedIn = false;
        String loggedUsername = null;
        while (!loggedIn) {
            JOptionPane.showMessageDialog(null, "🔐 Time to sign in.");

            String username = JOptionPane.showInputDialog(null, "Username:");
            if (username == null) return;

            String password = JOptionPane.showInputDialog(null, "Password:");
            if (password == null) return;

            boolean ok = login.loginUser(username.trim(), password);
            String msg = login.returnLoginStatus(ok, username.trim());
            JOptionPane.showMessageDialog(null, msg);

            if (ok) {
                loggedIn = true;
                loggedUsername = username.trim();
            }
        }

        // Catchy Welcome Message after login
        JLabel greetLabel = new JLabel(
                "<html><div style='text-align:center;'>"
                        + "<span style='font-size:18px;font-weight:bold;'>🎉 Welcome aboard, " + loggedUsername + "!</span><br>"
                        + "<span style='font-size:14px;'>NKQuickChat — Where your words travel fast 🚀</span>"
                        + "</div></html>");
        greetLabel.setHorizontalAlignment(SwingConstants.CENTER);
        JOptionPane.showMessageDialog(null, greetLabel, "Welcome", JOptionPane.PLAIN_MESSAGE);

        // === NUMBER OF MESSAGES ===
        int messagesToEnter = 0;
        while (messagesToEnter <= 0) {
            String nm = JOptionPane.showInputDialog(null, "How many messages would you like to send?");
            if (nm == null) return;
            try {
                messagesToEnter = Integer.parseInt(nm.trim());
                if (messagesToEnter <= 0)
                    JOptionPane.showMessageDialog(null, "Enter a number greater than 0.");
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid number.");
            }
        }

        List<Message> allMessages = new ArrayList<>();
        boolean quit = false;

        while (!quit) {
            String menu = "Please choose:\n1) 📤 Compose a message\n2) 🕑 View recent messages\n3) 🚪 Exit";
            String choice = JOptionPane.showInputDialog(null, menu);
            if (choice == null) return;

            switch (choice.trim()) {
                case "1":
                    if (allMessages.size() >= messagesToEnter) {
                        JOptionPane.showMessageDialog(null, "⚠ You've reached your message limit of " + messagesToEnter + ".");
                        break;
                    }

                    for (int i = allMessages.size(); i < messagesToEnter; i++) {
                        String recipient = JOptionPane.showInputDialog(null,
                                String.format("Recipient for message %d (e.g. +27...):", i + 1));
                        if (recipient == null) break;

                        String messageText = JOptionPane.showInputDialog(null, "Type your message (max 250 chars):");
                        if (messageText == null) break;

                        // Validate message length
                        if (messageText.length() > 250) {
                            JOptionPane.showMessageDialog(null,
                                    "⚠ Message too long! Please keep it under 250 characters.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            i--;
                            continue;
                        }

                        JOptionPane.showMessageDialog(null, "✅ Message sent.");

                        // Create and process message
                        Message m = new Message(allMessages.size(), recipient.trim(), messageText);
                        String actionResult = m.sendMessageViaDialog();
                        JOptionPane.showMessageDialog(null, actionResult);

                        if (m.getStatus() == Message.Status.STORED) {
                            try {
                                Message.storeMessagesToJson(
                                        Collections.singletonList(m),
                                        System.getProperty("user.home") + "/stored_messages.json");
                                JOptionPane.showMessageDialog(null,
                                        "💾 Message saved to JSON at " + System.getProperty("user.home") + "/stored_messages.json");
                            } catch (Exception ex) {
                                JOptionPane.showMessageDialog(null, "Failed to store message: " + ex.getMessage());
                            }
                        }

                        JOptionPane.showMessageDialog(null, m.printMessageDetails());
                        allMessages.add(m);

                        if (allMessages.size() >= messagesToEnter) break;
                    }

                    int totalSent = Message.returnTotalMessages(allMessages);
                    JOptionPane.showMessageDialog(null, "📊 Total messages sent: " + totalSent);
                    break;

                case "2":
                    JOptionPane.showMessageDialog(null, "🕑 Recent messages view coming soon!");
                    break;

                case "3":
                    quit = true;
                    break;

                default:
                    JOptionPane.showMessageDialog(null, "Invalid option. Choose 1, 2 or 3.");
            }
        }

        // === GOODBYE MESSAGE ===
        JLabel byeLabel = new JLabel(
                "<html><div style='text-align:center;'>"
                        + "<span style='font-size:20px;font-weight:bold;'>👋 Goodbye " + loggedUsername + "!</span><br>"
                        + "<span style='font-size:14px;'>Thank you for using NKQuickChat.<br>"
                        + "We hope to see you again soon! 💛</span>"
                        + "</div></html>");
        byeLabel.setHorizontalAlignment(SwingConstants.CENTER);
        JOptionPane.showMessageDialog(null, byeLabel, "Goodbye", JOptionPane.PLAIN_MESSAGE);
    }
}

